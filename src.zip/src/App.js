import { useDispatch, useSelector } from "react-redux";
import "./App.css";
import { useState } from "react";
import { decrement, increment, logIn, logOut, reset } from "./redux/actions";

function App() {
  const counter = useSelector((state) => (state.counter));
  const auth = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  return (
    <div className="App">
      <h1>
         Hello World <br /> A little Redux Project. YaaY!
      </h1>
      <h3>Counter</h3>
      <h3>{counter}</h3>
      <button onClick={() => dispatch(increment())}>Increase</button>
      <button onClick={() => dispatch(reset())}>Reset</button>
      <button onClick={() => dispatch(decrement())}>Decrease</button>

      <h2>For Logged in users only</h2>
      <p>Log in activate my action</p>
      <button onClick={() => dispatch(logIn())}>Login</button>
      <button onClick={() => dispatch(logOut())}>Logout</button>
      {auth ? (
        <div>
          <p>
            Success
          </p>
        </div>
      ) : (
        ""
      )}
    </div>
  );
}

export default App;